from tkinter import *
from PIL import ImageTk,Image

import psutil 
import os
import signal
import subprocess
import sys

window = Tk()
window.iconbitmap('englishmofo.ico')
window.title("Garena can suck my anal cavity.")
window.configure(bg = "black", pady = "25")
window.resizable(False, False)

process_id = 0
process_cmd = []
process_running = False

def checkIfProcessRunning(processName):
    for proc in psutil.process_iter():
        try:
            if processName.lower() in proc.name().lower():
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

for proc in psutil.process_iter():
    if proc.name() == "RiotClientServices.exe" :
        print(proc.pid)
        process_cmd = psutil.Process(proc.pid).cmdline()
        process_id = proc.pid
        print(process_cmd)



def kill_proc_tree(pid, sig=signal.SIGTERM, include_parent=True,
                   timeout=None, on_terminate=None):
    assert pid != os.getpid(), "won't kill myself"
    parent = psutil.Process(pid)
    children = parent.children(recursive=True)
    if include_parent:
        children.append(parent)
    for p in children:
        try:
            p.send_signal(sig)
        except psutil.NoSuchProcess:
            pass
    gone, alive = psutil.wait_procs(children, timeout=timeout,
                                    callback=on_terminate)
    return (gone, alive)

            


def englishTimeMotherFucker():
    process_cmd[4] = "--locale=en_US"
    print(process_cmd)
    kill_proc_tree(process_id)
    subprocess.Popen(process_cmd)
    window.destroy()




if checkIfProcessRunning('RiotClientServices'):

    englishMofo = ImageTk.PhotoImage(Image.open("englishmofo.gif"))
    englishMofoLabel = Label(image = englishMofo)
    englishMofoLabel.pack()
    isRunning = Label(window, padx = "50", pady = "25", bg = "black", fg = "#62ff00", font=("Arial", 14), text="League is fucking running. Click the Button Below to Restart League.")
    isRunning.pack()
    print('Yes, a league instance is running')
    process_running = True
    
    if(process_running == True):
        fuckingButton  = Button(window, padx = "10", bg = "#000000", fg ="#ffffff", font=("Arial", 12), text="English Mother Fucker", command=englishTimeMotherFucker)
        fuckingButton.pack()

        
else:
    notRunning = Label(window, padx = "50", pady = "25", bg = "black", fg = "red", font=("Arial", 14), text="League is not fucking running.")
    notRunning.pack()
    print('No, a league instance is not running')


window.mainloop()